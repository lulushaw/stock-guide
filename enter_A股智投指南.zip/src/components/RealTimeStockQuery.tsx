import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Search, TrendingUp, Loader2, AlertCircle } from 'lucide-react';
import { analytics } from '@/lib/analytics';

interface StockData {
  symbol: string;
  price: number;
  volume: number;
  fetched_at: string;
}

export function RealTimeStockQuery() {
  const [symbol, setSymbol] = useState('');
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<StockData | null>(null);
  const [error, setError] = useState<string | null>(null);

  const fetchStockPrice = async () => {
    const trimmedSymbol = symbol.trim().toUpperCase();
    if (!trimmedSymbol) {
      setError('请输入股票代码');
      return;
    }

    setLoading(true);
    setError(null);
    setResult(null);

    try {
      // GA4 事件追踪
      analytics.trackDataQuery('realtime_stock', trimmedSymbol);

      const response = await fetch(
        `https://dobdawwpmtndbledmlzd.supabase.co/functions/v1/fetch-stock-data?symbol=${trimmedSymbol}`
      );
      const data = await response.json();

      if (response.ok) {
        setResult(data);
      } else {
        setError(data.error || '查询失败，请稍后重试');
      }
    } catch (err) {
      setError('网络错误: ' + (err instanceof Error ? err.message : '未知错误'));
    } finally {
      setLoading(false);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      fetchStockPrice();
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <TrendingUp className="h-5 w-5 text-gold" />
          实时股票查询
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="flex gap-2">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="输入股票代码 (如 AAPL)"
              value={symbol}
              onChange={(e) => setSymbol(e.target.value.toUpperCase())}
              onKeyDown={handleKeyDown}
              className="pl-9"
            />
          </div>
          <Button onClick={fetchStockPrice} disabled={loading}>
            {loading ? (
              <>
                <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                查询中
              </>
            ) : (
              '查询'
            )}
          </Button>
        </div>

        {error && (
          <div className="mt-4 p-3 rounded-lg bg-destructive/10 text-destructive flex items-center gap-2">
            <AlertCircle className="h-4 w-4" />
            {error}
          </div>
        )}

        {result && (
          <div className="mt-4 p-4 rounded-lg bg-muted/50">
            <h3 className="text-xl font-bold text-primary mb-3">{result.symbol}</h3>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <div className="text-sm text-muted-foreground">当前价格</div>
                <div className="text-2xl font-bold text-stock-rise">
                  ${result.price.toFixed(2)}
                </div>
              </div>
              <div>
                <div className="text-sm text-muted-foreground">成交量</div>
                <div className="text-lg font-medium">
                  {result.volume.toLocaleString()}
                </div>
              </div>
            </div>
            <div className="mt-3 text-xs text-muted-foreground">
              更新时间: {new Date(result.fetched_at).toLocaleString('zh-CN')}
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
